# Appli Gardien V1
Application web installable iPhone/Android pour gérer les réclamations locataires.

## Installation GitHub Pages
1. Dépose tous les fichiers à la racine du dépôt.
2. Va dans Settings > Pages.
3. Source : Deploy from a branch.
4. Branch : main / root.
5. Ouvre le lien GitHub Pages.
6. Sur iPhone : Partage > Ajouter à l'écran d'accueil.

## Fonctionnalités
- 30 locataires de démonstration
- Remplissage automatique après choix du locataire
- Création de réclamations
- Statuts couleur
- Historique et recherche
- Export CSV
- Sauvegarde locale sur le téléphone
