const $ = id => document.getElementById(id);
const storeKey = 'appli_gardien_claims_v1';
let claims = JSON.parse(localStorage.getItem(storeKey) || '[]');
let deferredPrompt;

function fillTenantList(){
  $('tenantList').innerHTML = TENANTS.map(t => `<option value="${t.name} - ${t.unit} - ${t.residence}"></option>`).join('');
}
function findTenant(value){
  const v = value.toLowerCase();
  return TENANTS.find(t => `${t.name} ${t.unit} ${t.residence} ${t.address}`.toLowerCase().includes(v) || v.includes(t.name.toLowerCase()));
}
function setTenant(t){
  ['residence','address','building','stair','floor','unit','phone'].forEach(k => $(k).value = t ? t[k] : '');
}
$('tenantSearch').addEventListener('input', e => setTenant(findTenant(e.target.value)));

$('claimForm').addEventListener('submit', e => {
  e.preventDefault();
  const tenant = findTenant($('tenantSearch').value);
  if(!tenant){ alert('Choisis un locataire dans la liste.'); return; }
  claims.unshift({
    id: Date.now(), date: new Date().toLocaleString('fr-FR'), guardian:$('guardian').value,
    tenant, type:$('type').value, description:$('description').value,
    priority:$('priority').value, status:$('status').value
  });
  save(); e.target.reset(); setTenant(null); render();
});
function save(){ localStorage.setItem(storeKey, JSON.stringify(claims)); }
function render(){
  const q = $('historySearch').value.toLowerCase();
  const filtered = claims.filter(c => JSON.stringify(c).toLowerCase().includes(q));
  $('totalCount').textContent = claims.length;
  $('openCount').textContent = claims.filter(c => c.status === 'En cours').length;
  $('doneCount').textContent = claims.filter(c => c.status === 'Terminée').length;
  $('claimsList').innerHTML = filtered.length ? filtered.map(c => `
    <div class="claim">
      <div class="claimTop"><strong>${c.tenant.name} — ${c.tenant.unit}</strong><span class="badge ${c.status.replace(' ','-')}">${c.status}</span></div>
      <div class="muted">${c.date} • ${c.guardian} • ${c.tenant.residence}</div>
      <p><b>${c.type}</b> (${c.priority})<br>${c.description}</p>
      <button onclick="updateStatus(${c.id})" class="secondary">Changer statut</button>
      <button onclick="removeClaim(${c.id})" class="danger">Supprimer</button>
    </div>`).join('') : '<p class="muted">Aucune réclamation enregistrée.</p>';
}
window.updateStatus = id => {
  const order = ['En cours','Planifiée','Terminée','Annulée'];
  const c = claims.find(x => x.id === id); c.status = order[(order.indexOf(c.status)+1)%order.length]; save(); render();
};
window.removeClaim = id => { if(confirm('Supprimer cette réclamation ?')){ claims = claims.filter(c=>c.id!==id); save(); render(); }};
$('historySearch').addEventListener('input', render);
$('resetBtn').addEventListener('click',()=>{ if(confirm('Effacer les données de test ?')){claims=[];save();render();}});
$('exportBtn').addEventListener('click',()=>{
  const rows = [['Date','Gardien','Locataire','Résidence','Adresse','Bâtiment','Cage','Étage','Logement','Type','Priorité','Statut','Description'], ...claims.map(c=>[c.date,c.guardian,c.tenant.name,c.tenant.residence,c.tenant.address,c.tenant.building,c.tenant.stair,c.tenant.floor,c.tenant.unit,c.type,c.priority,c.status,c.description])];
  const csv = rows.map(r=>r.map(x=>'"'+String(x).replaceAll('"','""')+'"').join(';')).join('\n');
  const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'})); a.download='reclamations-appli-gardien.csv'; a.click();
});
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferredPrompt=e; $('installBtn').hidden=false; });
$('installBtn').addEventListener('click', async()=>{ if(deferredPrompt){ deferredPrompt.prompt(); deferredPrompt=null; }});
if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');
fillTenantList(); render();
